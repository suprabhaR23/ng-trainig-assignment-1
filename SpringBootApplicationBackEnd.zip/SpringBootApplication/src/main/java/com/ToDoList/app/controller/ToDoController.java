package com.ToDoList.app.controller;


import com.TodoList.app.Repository.TodoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/todos")
public class ToDoController {

    private final ToDoRepo todoRepository;

    public ToDoController(TodoRepo todoRepository) {
        this.todoRepository = todoRepository;
    }

    // 1. Create a new To-Do
    @PostMapping
    public ResponseEntity<ToDo> createTodo(@RequestBody Todo todo) {
        ToDo savedTodo = ToDoRepo.save(todo);
        return ResponseEntity.status(201).body(savedTodo);
    }

    // 2. Get all To-Dos
    @GetMapping
    public List<Todo> getAllTodos() {
        return ToDoRepo.findAll();
    }

    // 3. Get To-Do by ID
    @GetMapping("/{id}")
    public ResponseEntity<ToDo> getTodoById(@PathVariable Long id) {
        Optional<ToDo> todo = ToDoRepo.findById(id);
        return todo.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    // 4. Update To-Do
    @PutMapping("/{id}")
    public ResponseEntity<ToDo> updateTodo(@PathVariable Long id, @RequestBody ToDo updatedTodo) {
        return ToDoRepo.findById(id).map(todo -> {
            todo.setTitle(updatedTodo.getTitle());
            todo.setDescription(updatedTodo.getDescription());
            todo.setDueDate(updatedTodo.get
        }
    }

}