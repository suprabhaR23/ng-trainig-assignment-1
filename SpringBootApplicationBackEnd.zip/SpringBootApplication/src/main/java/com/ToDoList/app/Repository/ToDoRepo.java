package com.ToDoList.app.Repository;

public interface ToDoRepo {

}
