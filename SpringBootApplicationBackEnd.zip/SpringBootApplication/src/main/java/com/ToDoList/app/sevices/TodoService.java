package com.ToDoList.app.sevices;

import java.util.List;
import java.util.Optional;

@Service
public class TodoService {

    private final TodoRepository todoRepository;

    public TodoService(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    // Create a new to-do
    public Todo createTodo(Todo todo) {
        return todoRepository.save(todo);
    }

    // Get all to-dos
    public List<Todo> getAllTodos() {
        return todoRepository.findAll();
    }

    // Get to-do by ID
    public Optional<Todo> getTodoById(Long id) {
        return todoRepository.findById(id);
    }

    // Update a to-do
    public Optional<Todo> updateTodo(Long id, Todo updatedTodo) {
        return todoRepository.findById(id).map(todo -> {
            todo.setTitle(updatedTodo.getTitle());
            todo.setDescription(updatedTodo.getDescription());
            todo.setDueDate(updatedTodo.getDueDate());
            todo.setCompleted(updatedTodo.isCompleted());
            return todoRepository.save(todo);
        });
    }

    // Mark a to-do as completed
    public Optional<Todo> completeTodo(Long id) {
        return todoRepository.findById(id).map(todo -> {
            todo.setCompleted(true);
            return todoRepository.save(todo);
        });
    }

    // Delete a to-do
    public boolean deleteTodo(Long id) {
        return todoRepository.findById(id).map(todo -> {
            todoRepository.delete(todo);
            return true;
        }).orElse(false);
    }
}