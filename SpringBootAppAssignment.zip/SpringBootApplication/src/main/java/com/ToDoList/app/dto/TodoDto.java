package com.ToDoList.app.dto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TodoItemRepository extends JpaRepository<TodoItem, String> {

    
    List<TodoItem> findByIsCompleted(boolean isCompleted);
}